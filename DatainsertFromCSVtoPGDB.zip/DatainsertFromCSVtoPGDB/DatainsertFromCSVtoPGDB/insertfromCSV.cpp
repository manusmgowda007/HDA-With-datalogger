#include "insertfromCSV.h"

void exit_nicely(PGconn* conn)
{
	PQfinish(conn);
	exit(1);
}

void insertDatafromCSV(int tabletype)
{
    std::string strConnection;
    strConnection = "dbname=History_Data_Access user=postgres password=newPass host=localhost port=5432";

    //const char* conninfo = "DRIVER={PostgreSQL Unicode};SERVER=localhost;PORT=5432;DATABASE=History_Data_Access;UID=postgres;PWD=newPass";
    PGconn* conn = PQconnectdb(strConnection.c_str());
    if (PQstatus(conn) != CONNECTION_OK) {
        std::cerr << "Connection to database failed: " << PQerrorMessage(conn) << std::endl;
        exit_nicely(conn);
    }
    std::string filenametopen = "";
    if (tabletype == 1)
    {
        std::ifstream file("D:\\csvs\\2025-2-1_0_Scalar.csv");
        if (!file.is_open())
        {
            std::cout << "file is not opened\n";
        }
        std::string line;
        std::getline(file, line); // Skip header

        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string node_id, hist_timestamp, datatype, bit_value, integer_value, float_Value, double_value, string_value, status;

            std::getline(ss, node_id, ',');
            std::getline(ss, hist_timestamp, ',');
            std::getline(ss, datatype, ',');
            std::getline(ss, bit_value, ',');
            std::getline(ss, integer_value, ',');
            std::getline(ss, float_Value, ',');
            std::getline(ss, double_value, ',');
            std::getline(ss, string_value, ',');
            std::getline(ss, status, ',');

            std::string query = "INSERT INTO hda_scalar (node_id, hist_timestamp, datatype, bit_value, integer_value, float_Value, double_value, string_value, status) "
                "VALUES (" + node_id + "," + hist_timestamp + ", '" + datatype + "', " + bit_value + ", " + integer_value + ", " + float_Value + "," + double_value + ", '" + string_value + "' ," + status + ");";

            PGresult* res = PQexec(conn, query.c_str());

            if (PQresultStatus(res) != PGRES_COMMAND_OK) {
                std::cerr << "INSERT failed: " << PQerrorMessage(conn) << std::endl;
                PQclear(res);
                exit_nicely(conn);
            }

            PQclear(res);
        }

        PQfinish(conn);

        std::cout << "Data inserted successfully! hda_scalar table" << std::endl;
    }
    else if (tabletype == 2)
    {
        std::ifstream file("D:\\csvs\\2025-2-1_0.csv");
        if (!file.is_open())
        {
            std::cout << "file is not opened\n";
        }
        std::string line;
        std::getline(file, line); // Skip header

        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string node_id, hist_timestamp, datatype, dimension1, arrayvalue, status;

            std::getline(ss, node_id, ',');
            std::getline(ss, hist_timestamp, ',');
            std::getline(ss, datatype, ',');
            std::getline(ss, dimension1, ',');
            std::getline(ss, arrayvalue, ',');
            std::getline(ss, status, ',');

            //arrayvalue = "3f000000c060000040b00000412c0000bf600000";
            // Convert hexadecimal string to BYTEA format
            std::string bytea_value = "decode('" + arrayvalue + "', 'hex')";

            std::string query = "INSERT INTO hda_1d_array (node_id, hist_timestamp, datatype, dimension1, arrayvalue, status) "
                "VALUES (" + node_id + "," + hist_timestamp + ", '" + datatype + "', " + dimension1 + ", " + bytea_value + ", " + status + ");";

            PGresult* res = PQexec(conn, query.c_str());

            if (PQresultStatus(res) != PGRES_COMMAND_OK) {
                std::cerr << "INSERT failed: " << PQerrorMessage(conn) << std::endl;
                PQclear(res);
                exit_nicely(conn);
            }

            PQclear(res);
        }

        PQfinish(conn);

        std::cout << "Data inserted successfully! hda_1d_array table" << std::endl;
    }
    else if(tabletype==3) {
        std::cout << "Data inserted successfully for hda_dd_array table!" << std::endl;
    }
    else {
        std::cout << "wrong table type\n";
    }
}
int main()
{
    int inputdatatostoredb = 0;
    std::cout << "Enter the types of node which you want to store the data to DB from CSV \n 1 for Scalar.\n 2 for 1D Array.\n 3 or 2D Array\n";
    std::cin >> inputdatatostoredb;
    insertDatafromCSV(inputdatatostoredb);

}
