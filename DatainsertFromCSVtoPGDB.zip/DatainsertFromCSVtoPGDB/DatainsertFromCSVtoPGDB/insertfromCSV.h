#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <libpq-fe.h>
void exit_nicely(PGconn* conn);
void insertDataforCSV(int tabletype);